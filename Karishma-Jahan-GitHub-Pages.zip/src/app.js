/* Framework-free, allowlisted routes; no remote HTML injection. */
const $ = (s, root = document) => root.querySelector(s);
const routes = {
 '/': {title:'Home', template:'home'}, '/about':{title:'About',template:'about'},
 '/services':{title:'Services',template:'services'}, '/portfolio':{title:'Portfolio',template:'portfolio'},
 '/blog':{title:'Blog',template:'blog'}, '/content':{title:'Content',template:'content'}, '/hire':{title:'Hire',template:'hire'},
 '/portfolio/social-launch':{title:'Social launch kit · Concept',template:'project'},
 '/portfolio/search-foundation':{title:'Search foundation · Concept',template:'project'},
 '/portfolio/campaign-blueprint':{title:'Campaign blueprint · Concept',template:'project'},
 '/blog/content-with-a-purpose':{title:'Content with a purpose',template:'article'}
};
const main = $('#main'), panel = $('#section-panel'), panelContent = $('#panel-content');
let returnFocus = null, panelOwned = false, nestedReturn = null;
const header = $('.site-header');
window.addEventListener('scroll', () => header.classList.toggle('compact', scrollY > 32), {passive:true});
const menuButton = null;
function closeMenu(){}
const sectionPaths=['/','/about','/services','/portfolio','/blog','/content','/hire'];
function sectionId(path){return path==='/'?'home':path.slice(1)}
function focusSection(path){const target=document.getElementById(sectionId(path));if(target){target.scrollIntoView({behavior:'instant',block:'start'});target.querySelector('.folder-heading h2')?.focus({preventScroll:true})}}
// GitHub Pages serves static files; query routes work at root and repository subpaths.
function currentRoute(){return new URL(location.href).searchParams.get('route') || '/'}
function safePath(path){return Object.hasOwn(routes,path) ? path : null}
function urlFor(path,view='panel'){
 if(!safePath(path))throw new Error('Unknown route');
 const url=new URL('index.html',location.href);
 url.search='';url.hash='';url.searchParams.set('route',path);
 url.searchParams.set('view',view);
 if(view==='panel')url.searchParams.set('background','/');
 return url;
}
function fill(target,path){
 target.dataset.path=path;const route=routes[path];target.replaceChildren(document.getElementById('tpl-'+route.template).content.cloneNode(true));
 if(route.template==='project'){
  const index=['/portfolio/social-launch','/portfolio/search-foundation','/portfolio/campaign-blueprint'].indexOf(path);
  $('h1',target).textContent=route.title;
  const img=$('.project-preview',target); img.src=window.projectImages[index];img.alt=route.title+' marketing concept';
  $('.asset-link',target).href=window.projectImages[index];
 }
 hydrate(target); const heading=$('h1',target);if(heading)heading.tabIndex=-1;
}
function setMetadata(path){
 const title=routes[path]?.title || 'Page not found';document.title=title+' — Karishma Jahan';
 document.querySelectorAll('[data-nav]').forEach(a=>{a.removeAttribute('aria-current');if(a.getAttribute('href')===path || (path.startsWith(a.getAttribute('href')+'/') && a.getAttribute('href')!=='/'))a.setAttribute('aria-current','page')});
}
function render({focus=true}={}){
 const path=currentRoute();setMetadata(path);
 if(!safePath(path)){
  if(panel.open)panel.close();main.innerHTML='<div class="wrap page"><h1 tabindex="-1">Page not found</h1><p>The requested page could not be found.</p><a href="/" data-page>Return home</a></div>';if(focus)$('h1',main).focus();return;
 }
 if(sectionPaths.includes(path)){
  if(panel.open)panel.close();
  if(main.dataset.path!=='/')fill(main,'/');
  const hash=location.hash.slice(1);
  if(focus || path!=='/' || hash)requestAnimationFrame(()=>focusSection(hash && sectionPaths.includes('/'+hash)?'/'+hash:path));
  return;
 }
 const url=new URL(location.href), isPanel=url.searchParams.get('view')==='panel' && path!=='/' && typeof panel.showModal==='function';
 if(isPanel){
  if(main.dataset.path!=='/')fill(main,'/');fill(panelContent,path);$('#panel-label').textContent=routes[path].title;
  $('#panel-new-tab').href=urlFor(path,'page');
  if(!panel.open)panel.showModal();
  if(focus)$('h1',panelContent)?.focus();
 }else{
  if(panel.open)panel.close();if(main.dataset.path!==path)fill(main,path);if(focus)$('h1',main)?.focus();
 }
}
function openInNewTab(path){
 const url=urlFor(path,'page');
 // noopener may return null even when successful: do NOT infer blocking from its return value.
 window.open(url.href, '_blank', 'noopener');
}
function openSection(path,trigger){
 if(!safePath(path))return;
 if(typeof panel.showModal!=='function'){openInNewTab(path);return}
 const alreadyOpen=panel.open;
 if(!alreadyOpen){returnFocus=trigger || document.activeElement;panelOwned=true}
 history[alreadyOpen ? 'replaceState' : 'pushState']({portfolioPanel:true},'',urlFor(path,path==='/'?'page':'panel'));
 render();closeMenu();
}
function closePanel(){
 if(!panel.open)return;
 if(panelOwned && history.state?.portfolioPanel){history.back()}
 else{history.replaceState({},'',urlFor('/','page'));render({focus:false});restoreFocus()}
}
function restoreFocus(){
 if(returnFocus?.isConnected && returnFocus.getClientRects().length)returnFocus.focus();else $('.brand').focus();
 returnFocus=null;panelOwned=false;
}
$('#panel-close').addEventListener('click',closePanel);
panel.addEventListener('cancel',e=>{e.preventDefault();closePanel()});
// Native dialog supplies inert background + focus containment. Explicit wrapping supports older implementations.
function trapFocus(e){
 if(e.key!=='Tab')return;
 const nodes=[...e.currentTarget.querySelectorAll('a[href],button:not([disabled]),input:not([disabled]),textarea:not([disabled]),select:not([disabled]),[tabindex="0"]')].filter(el=>el.getClientRects().length);
 const first=nodes[0],last=nodes.at(-1);
 if(!first){e.preventDefault();return}
 if(e.shiftKey && (document.activeElement===first || !nodes.includes(document.activeElement))){e.preventDefault();last.focus()}
 else if(!e.shiftKey && (document.activeElement===last || !nodes.includes(document.activeElement))){e.preventDefault();first.focus()}
}
panel.addEventListener('keydown',trapFocus);
window.addEventListener('popstate',()=>{
 const wasOpen=panel.open;render({focus:false});
 if(wasOpen && !panel.open)restoreFocus();else if(panel.open)$('h1',panelContent)?.focus();else $('h1',main)?.focus();
});
document.addEventListener('click',e=>{
 const link=e.target.closest('a[data-panel],a[data-page],a[data-new-tab]');
 if(!link || e.button!==0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey)return;
 const path=link.dataset.route || new URL(link.href,location.href).pathname;
 if(!safePath(path))return;
 e.preventDefault();
 if(sectionPaths.includes(path) && !link.hasAttribute('data-new-tab')){
  const url=urlFor('/','page');url.hash=sectionId(path);
  history.pushState({},'',url);if(panel.open)panel.close();
  if(main.dataset.path!=='/')fill(main,'/');focusSection(path);return;
 }
 if(link.hasAttribute('data-new-tab'))openInNewTab(path);
 else if(link.hasAttribute('data-page')){history.pushState({},'',urlFor(path,'page'));render();closeMenu();window.scrollTo(0,0)}
 else openSection(path,link);
});
const lightbox=$('#lightbox');lightbox.addEventListener('keydown',trapFocus);
lightbox.addEventListener('close',()=>nestedReturn?.focus());
$('#lightbox-close').addEventListener('click',()=>lightbox.close());
function hydrate(root){
 // In exported standalone HTML, rewrite links so modifier-click and no-JS-safe anchors retain deep links.
 root.querySelectorAll('a[data-panel],a[data-page],a[data-new-tab]').forEach(a=>{
  const path=a.dataset.route || new URL(a.getAttribute('href'),location.href).pathname;
  if(safePath(path)){a.dataset.route=path;a.href=urlFor(path,a.hasAttribute('data-panel')?'panel':'page')}
 });
 root.querySelectorAll('[data-filter]').forEach(button=>button.addEventListener('click',()=>{
  const region=button.closest('[data-gallery]');
  region.querySelectorAll('[data-filter]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
  let count=0;region.querySelectorAll('[data-category]').forEach(card=>{card.hidden=button.dataset.filter!=='all' && card.dataset.category!==button.dataset.filter;if(!card.hidden)count++});
  $('[data-results]',region).textContent=count+' items shown';
 }));
 root.querySelectorAll('[data-zoom]').forEach(button=>button.addEventListener('click',()=>{
  if(typeof lightbox.showModal!=='function')return;
  const source=$('img',button);$('#lightbox-image').src=source.src;$('#lightbox-image').alt=source.alt;nestedReturn=button;lightbox.showModal();$('#lightbox-close').focus();
 }));
 root.querySelectorAll('form[data-hire]').forEach(form=>form.addEventListener('submit',async e=>{
  e.preventDefault();let first=null;
  form.querySelectorAll('[data-field]').forEach(input=>{
   const error=$('#'+input.id+'-error',form);let message='';
   if(!input.validity.valid)message=input.type==='email'?'Enter a valid email address.':input.type==='checkbox'?'Please confirm your consent.':'Please complete this required field.';
   if(input.type!=='checkbox' && !input.value.trim())message='Please complete this required field.';
   input.setAttribute('aria-invalid',String(Boolean(message)));error.textContent=message;if(message && !first)first=input;
  });
  const status=$('[role="status"]',form);
  if(first){status.textContent='Please review the highlighted fields.';first.focus();return}
  // Production contract: same-origin POST /api/contact -> 2xx JSON {ok:true}.
  const endpoint=form.dataset.endpoint;
  if(!endpoint){status.textContent='Your details have been validated. This demonstration form is not connected to a delivery service; no message has been sent.';return}
  const submit=$('button[type="submit"]',form);submit.disabled=true;status.textContent='Sending your enquiry…';
  try{
   const response=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(Object.fromEntries(new FormData(form)))});
   if(!response.ok)throw new Error('Request failed');const result=await response.json();if(result.ok!==true)throw new Error('Not confirmed');
   status.textContent='Thank you. Your enquiry has been received.';form.reset();
  }catch{status.textContent='Your enquiry could not be sent. Please try again; your entries have been preserved.'}
  finally{submit.disabled=false}
 }));
}
hydrate(header);hydrate(document.querySelector('footer'));render({focus:false});

// Reference-style navigation: scroll to existing sections and disclose links on mobile.
const referenceToggle = document.getElementById('header-menu-button');
const referenceNav = document.getElementById('header-navigation');
function dismissReferenceMenu(){referenceNav?.classList.remove('is-open');referenceToggle?.setAttribute('aria-expanded','false')}
referenceToggle?.addEventListener('click',()=>{
 const open=referenceNav.classList.toggle('is-open');
 referenceToggle.setAttribute('aria-expanded',String(open));
});
referenceNav?.addEventListener('click',e=>{if(e.target.closest('a'))dismissReferenceMenu()});
header.addEventListener('keydown',e=>{if(e.key==='Escape' && referenceNav?.classList.contains('is-open')){dismissReferenceMenu();referenceToggle.focus()}});
if('IntersectionObserver' in window){
 const observer=new IntersectionObserver(entries=>{
  for(const entry of entries){if(entry.isIntersecting){
   referenceNav?.querySelectorAll('a').forEach(link=>{
    const path=link.dataset.route;const id=path==='/'?'home':path?.slice(1);
    if(id===entry.target.id)link.setAttribute('aria-current','page');else link.removeAttribute('aria-current');
   });
  }}
 },{rootMargin:'-12% 0px -72% 0px',threshold:0});
 document.querySelectorAll('main .folder-section').forEach(section=>observer.observe(section));
}

// Persistent, keyboard-accessible theme control; storage is optional in restricted previews.
const themeButton=document.getElementById('theme-toggle');
function applyTheme(theme){
 const dark=theme==='dark';document.documentElement.dataset.theme=theme;
 themeButton?.setAttribute('aria-pressed',String(dark));
 if(themeButton)themeButton.title='Switch to '+(dark?'light':'dark')+' theme';
 const label=document.getElementById('theme-label');if(label)label.textContent=dark?'Dark':'Light';
 const icon=document.getElementById('theme-icon');if(icon)icon.setAttribute('d',dark?'M20.9 13a9 9 0 0 1-9.9-9.9A9 9 0 1 0 20.9 13Z':'M12 3V1m0 22v-2M3 12H1m22 0h-2M4.2 4.2 2.8 2.8m18.4 18.4-1.4-1.4M4.2 19.8l-1.4 1.4M21.2 2.8l-1.4 1.4M17 12a5 5 0 1 1-10 0 5 5 0 0 1 10 0Z');
 document.querySelector('meta[name="theme-color"]')?.setAttribute('content',dark?'#0B1020':'#F5F9FF');
}
applyTheme(document.documentElement.dataset.theme||'dark');
themeButton?.addEventListener('click',()=>{const theme=document.documentElement.dataset.theme==='dark'?'light':'dark';applyTheme(theme);try{localStorage.setItem('kj-theme',theme)}catch(e){}});
window.addEventListener('storage',e=>{if(e.key==='kj-theme'&&(e.newValue==='dark'||e.newValue==='light'))applyTheme(e.newValue)});
