# Deploy the portfolio with GitHub Pages

This package is prepared for **Karishma Jahan’s current portfolio**, including the circular portrait, responsive header/footer and Light/Dark toggle.

**Choose one deployment method:**
- **Method A — GitHub Actions:** recommended for ongoing edits; builds automatically from source.
- **Method B — one-file upload:** easiest first deployment; publishes the already-built `index.html`.

No Node.js, npm, paid hosting or backend is required. A GitHub account is required. Nothing has been published to an account by this delivery.

## Package contents
```text
github-deploy/
├── .github/
│   └── workflows/
│       └── deploy.yml        # Automatic deployment workflow
├── .gitignore
├── build_site.py             # Standard-library Python build
├── index.html                # Ready-to-upload website
├── DEPLOY-GUIDE.md
├── README.md
└── src/
    ├── build.py
    ├── render_shell.py
    ├── footer_template.py
    ├── hire_template.py
    ├── app.js
    ├── styles.css
    ├── tokens.json
    └── assets/              # Portrait, emblem and concept SVGs
```

The ZIP contains these files at its root. Upload the **extracted contents**, not the ZIP file or an enclosing folder. The workflow must live at `.github/workflows/deploy.yml` in the repository root.

## Before publishing
- Confirm permission to publish the uploaded photograph.
- Review the name, content and proposed services. The original CV, phone/email and sensitive identity details are not included.
- Concepts remain labeled as illustrative; no marketing experience or client results are fabricated.
- The contact form is a **demonstration and sends nothing**. GitHub Pages cannot execute Python servers, send email or securely hold API keys. Real enquiries need an external form service or separately hosted backend.
- Social buttons remain unavailable until approved profile URLs exist.
- The HTML intentionally contains `noindex,nofollow` pending content approval. This does **not** make a public website private; it only requests exclusion from search indexing.

## Method A — automatic deployment with GitHub Actions
### Step 1: Create a repository
1. Sign in at `https://github.com`.
2. Select **+ → New repository**.
3. Enter a repository name, for example **portfolio**.
4. Select **Public** for the simplest GitHub Pages setup on a free personal account.
5. Select **Add a README file** to initialize the repository.
6. Select **Create repository**.

Expected project URL:
```text
https://YOUR-USERNAME.github.io/portfolio/
```
Replace `YOUR-USERNAME` with the real account name. For a repository named exactly `YOUR-USERNAME.github.io`, the site instead publishes at `https://YOUR-USERNAME.github.io/`.

### Step 2: Upload the extracted project files
1. Download and extract `Karishma-Jahan-GitHub-Pages.zip`.
2. In the repository, select **Add file → Upload files**.
3. Upload the extracted `src` folder, `build_site.py`, `index.html`, `.gitignore` and documentation.
4. Enter a commit message such as **Add portfolio website**.
5. Commit to **main**.

**Important:** some file pickers hide `.github`. If the workflow folder did not upload, create it explicitly:
1. Select **Add file → Create new file**.
2. Enter `.github/workflows/deploy.yml` as the filename.
3. Paste the complete content of the included `deploy.yml` file.
4. Select **Commit changes** and commit to `main`.

The repository root must contain `build_site.py` and `src/`; placing them inside another `github-deploy/` folder will break the workflow paths.

### Step 3: Enable GitHub Pages
1. Open the repository’s **Settings**.
2. Select **Pages** in the sidebar.
3. Under **Build and deployment → Source**, select **GitHub Actions**.
4. Do not select “Deploy from a branch” for Method A.

The workflow uses only the repository’s automatic `GITHUB_TOKEN`; no personal token needs to be pasted into the website or workflow.

### Step 4: Run the deployment
1. Open the repository’s **Actions** tab.
2. Select **Deploy portfolio to GitHub Pages**.
3. Select **Run workflow → main → Run workflow** if the upload run did not finish successfully.
4. Wait for both **build** and **deploy** to turn green.
5. Open the published URL from the deployment summary or **Settings → Pages**.

If an earlier run failed before Pages was enabled, rerun it after Step 3. Do not add credentials to fix that configuration issue.

### Step 5: Verify the live website
- The correct name, photo, header and footer appear.
- Main links scroll to visible sections.
- A concept project opens; refreshing its URL works.
- “Open in new tab” stays under the same repository path.
- The Light/Dark control switches themes and preserves the choice when storage is available.
- Mobile layout and menu work.
- The form clearly reports demonstration status rather than claiming delivery.

### Step 6: Make future edits
1. Edit the relevant file under `src/`.
2. Commit to `main`.
3. Wait for the Actions build/deployment to complete.
4. Refresh the live site; use a hard refresh if an older copy is cached.

| Change | File |
|---|---|
| Name, hero, About, services or section content | `src/build.py` |
| Footer content/social profile configuration | `src/footer_template.py` |
| Form labels and enquiry introduction | `src/hire_template.py` |
| Colors, typography, circular frame or layout | `src/styles.css` |
| Theme, filters, history or interaction logic | `src/app.js` |
| Metadata and indexing directives | `src/render_shell.py` |
| Portrait | `src/assets/portrait.webp` |

The portrait file should be square; its filename and format should stay unchanged unless the corresponding code is updated. Do not publish private identity documents in the repository.

**For Method A, edit source, not the generated root `index.html`.** The Actions workflow rebuilds `_site/index.html` from `src/` on every deployment. `_site` is the artifact, not a folder that needs to be uploaded manually.

## Method B — simplest one-file upload
This method is independent of Actions. **Do not upload or enable the deployment workflow when choosing this method.**

1. Create a public repository, for example `portfolio`, with a README.
2. Select **Add file → Upload files**.
3. Upload only the provided **index.html** to the repository root, then commit to `main`.
4. Open **Settings → Pages**.
5. Under **Source**, select **Deploy from a branch**.
6. Select **main**, then **/(root)**, and select **Save**.
7. Wait for the Pages deployment to finish, then open the URL shown in Pages settings.

The page embeds all required styling, JavaScript and images. The extra source and asset files are not required for this method.

Future updates: replace the root `index.html` with a newly built copy. A local rebuild uses `python build_site.py` from the extracted full package. No package installation is required.

A custom `404.html` is generated for the Actions artifact. Method B uses GitHub’s default missing-page behavior unless that generated file is also uploaded.

## Link format and deep links
GitHub Pages has no general server-side route rewrite. This deployment deliberately uses static-file-safe query and hash links, not clean routes that would fail on refresh.

Examples:
```text
https://YOUR-USERNAME.github.io/portfolio/
https://YOUR-USERNAME.github.io/portfolio/index.html?route=%2F&view=page#about
https://YOUR-USERNAME.github.io/portfolio/index.html?route=%2Fportfolio%2Fsocial-launch&view=panel&background=%2F
https://YOUR-USERNAME.github.io/portfolio/index.html?route=%2Fportfolio%2Fsocial-launch&view=page
```

Use links generated by the deployed website. A clean URL such as `/portfolio/social-launch` is **not** supported by this static deployment and will return a 404. The package does not rely on a fragile 404-to-SPA redirect trick.

## Optional: enable search indexing after approval
In `src/render_shell.py`, find:
```html
<meta name="robots" content="noindex,nofollow">
```
Remove that tag only after the public content is approved, then redeploy. For Method B, rebuild and replace `index.html`. Add a real-domain canonical URL, social preview metadata and sitemap as part of an SEO launch review; query-based client-rendered detail pages are not a complete pre-rendered SEO implementation.

## Troubleshooting
| Problem | Fix |
|---|---|
| Actions workflow does not appear | Check the exact path `.github/workflows/deploy.yml`. Confirm Actions are enabled for the repository. |
| Workflow never runs after a commit | It listens to `main`. If the default branch is different, change `branches: [main]` in the workflow. |
| Pages configuration/deployment failure | Select **Settings → Pages → GitHub Actions** for Method A, then rerun. Check repository/organization Pages permissions. |
| Environment approval required | Approve the `github-pages` deployment if protection rules require it. |
| `build_site.py` not found | Upload project contents at repository root, not inside an extra enclosing folder. |
| Homepage returns 404 | Check deployment completion, repository visibility/Pages availability, root `index.html` and the exact published URL. |
| A project returns 404 on refresh | Use the generated `index.html?route=...` link, not a clean server route. |
| Old version still appears | Check the latest Actions run, verify edits were made in `src/`, then hard-refresh. |
| Theme does not persist | Private browsing or browser policy may block storage. Switching still works for the current page. |
| Contact message is not delivered | Expected until an external form endpoint or backend is configured; GitHub Pages is static hosting. |

## Optional: upload using Git locally
Run inside the extracted package after creating an empty repository. This alternative assumes Git is installed and GitHub authentication is already configured.
```bash
git init
git branch -M main
git add .
git commit -m "Add portfolio and GitHub Pages deployment"
git remote add origin https://github.com/YOUR-USERNAME/portfolio.git
git push -u origin main
```
Replace `YOUR-USERNAME` and the repository name before running. Do not embed passwords/tokens in the remote URL or commit them to files. If the remote already contains a README or other commits, clone it first and copy the extracted project files into that clone rather than forcing a push.

Then complete **Method A, Steps 3–5** in the GitHub interface.

## Official reference
GitHub Pages documentation: https://docs.github.com/en/pages
