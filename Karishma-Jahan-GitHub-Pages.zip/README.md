# Karishma Jahan — GitHub Pages Deployment

See **DEPLOY-GUIDE.md** for the complete step-by-step guide.

## Recommended setup
1. Upload these extracted files at the root of a public GitHub repository.
2. Ensure `.github/workflows/deploy.yml` is included.
3. Select **Settings → Pages → Source → GitHub Actions**.
4. Run the deployment workflow or push to `main`.

## Build locally
```bash
python build_site.py
```
Python standard library only; no npm or pip dependencies. `_site` is the deployable output. Root `index.html` is also generated for the one-file deployment alternative described in the guide.

## Important
- This edition uses query-based detail URLs to support repository subpaths and refresh without route rewrites.
- Do not replace this edition's `src/app.js` with the preview-server version, which uses clean routes.
- The form is demo-only; no message is sent without a separate secure endpoint.
- Keep concept labels, verify publication rights for the portrait and do not commit private CVs or credentials.
- Search indexing is disabled pending content approval.
