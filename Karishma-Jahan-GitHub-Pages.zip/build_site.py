"""Build a subpath-safe GitHub Pages artifact. Python standard library only."""
from pathlib import Path
import html
import re
import shutil
import subprocess
import sys
from urllib.parse import urlencode, urlsplit, parse_qs
ROOT=Path(__file__).resolve().parent
subprocess.run([sys.executable,str(ROOT/'src'/'build.py')],check=True)
text=(ROOT/'src'/'index.html').read_text()
# Preserve functional static anchors even before client-side hydration.
paths={'/','/about','/services','/portfolio','/blog','/content','/hire','/portfolio/social-launch','/portfolio/search-foundation','/portfolio/campaign-blueprint','/blog/content-with-a-purpose'}
def anchor(match):
 tag=match.group(0)
 href=re.search(r'href="([^"]+)"',tag)
 if not href:return tag
 parsed=urlsplit(html.unescape(href.group(1)))
 if parsed.scheme or parsed.netloc or parsed.path not in paths:return tag
 path=parsed.path
 view=parse_qs(parsed.query).get('view',['panel' if 'data-panel' in tag else 'page'])[0]
 query={'route':path,'view':view}
 if view=='panel':query['background']='/'
 value='index.html?'+urlencode(query)
 tag=tag.replace(href.group(0),'href="'+html.escape(value,quote=True)+'"')
 if 'data-route=' not in tag:tag=tag[:-1]+' data-route="'+path+'">'
 return tag
text=re.sub(r'<a\b[^>]*>',anchor,text)
out=ROOT/'_site'
if out.exists():shutil.rmtree(out)
out.mkdir()
(out/'index.html').write_text(text)
(out/'.nojekyll').write_text('')
# A real not-found response instead of a fragile SPA redirect workaround.
(out/'404.html').write_text('''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Page not found</title><style>body{margin:0;padding:10vw;background:#0b1020;color:#ecf2ff;font:18px/1.7 system-ui}h1{font-size:3rem}code{color:#6ee7f5}</style><h1>Page not found</h1><p>This portfolio uses <code>index.html?route=...</code> for deep links.</p><p>Open the published site’s main address, then select a section or project.</p></html>''')
# Ready-made one-file upload alternative. Rebuilt from src; do not edit by hand.
(ROOT/'index.html').write_text(text)
print('Built _site/index.html and the ready-to-upload index.html.')
